"""
Orchestrates the full CMA-ES benchmarking pipeline.
"""

from cmaes import Result, CMAES
from collections import defaultdict
from controllers import PopulationController, IPOP, Default
from dataclasses import asdict, dataclass
from ioh import problem, get_problem, ProblemClass
import os
from typing import Any, Callable, Dict, List, Tuple
import numpy as np
import pandas as pd



# Benchmark configuration

# Independent repeats per (function × instance × controller)
N_RUNS: int = 1

# Random seed for reproducibility
BASE_SEED: int = 0

# List of controllers to run on
CONTROLLERS: List[PopulationController] = [IPOP, Default]


# Averages of result dataclass
@dataclass
class MeanResult:
    """
    Summary statistics for one (function, instance, controller) combination.
    """
    func_name: str
    fid: int
    iid: int
    dim: int
    func_class: str
    controller: str
    # budget: int
    n_runs: int
    # performance
    mean_fopt: float
    std_fopt: float
    median_fopt: float
    best_fopt: float
    worst_fopt: float
    # convergence
    # success_rate: float       # fraction of runs with fopt < convergence_target
    # resource usage
    mean_used_budget: float
    std_used_budget: float
    # restart statistics
    mean_n_restarts: float
    mean_initial_lambda: float
    mean_final_lambda: float



# Benchmark runner
def run_benchmark_coco(
    controllers: List[PopulationController] = CONTROLLERS,
    n_runs: int = N_RUNS,
    seed: int = BASE_SEED,
) -> Tuple[List[Result], List[MeanResult]]:
    """
    Run the full benchmark and return raw and aggregated results.

    Parameters
    -
    controllers : list of controllers to be evaluated
    n_runs : int
    seed : int
    
    Returns
    -
    all_results : list of Result
    aggregated : list of MeanResult
    """
    all_results: List[Result] = []

    for fid in range(1, 25):

        count = 0
        for controller_type in controllers:

            phase_fopt_list: List[float] = []

            for r in range(n_runs):
                np.random.seed(seed + count)

                controller = controller_type()
                runner = CMAES(controller)

                func = get_problem(fid)

                result = runner.run(
                    fitness_func=func,
                    func_name=func.meta_data.name,
                    fid=fid,
                    iid=1,
                    dim=5,
                    func_class="BBOB",
                    run_index=r,
                )
                all_results.append(result)
                phase_fopt_list.append(result.fopt)
                count += 1


    aggregated = _aggregate(all_results)
    return all_results, aggregated



def _aggregate(results: List[Result]) -> List[MeanResult]:
    """Group results by (func_name, iid, controller_label) and compute stats."""
    groups: Dict[Tuple, List[Result]] = defaultdict(list)
    for r in results:
        groups[(r.func_name, r.iid, r.controller_name)].append(r)

    aggregated: List[MeanResult] = []
    for (func_name, iid, ctrl_label), group in sorted(groups.items()):
        fopts       = np.array([g.fopt for g in group])
        budgets     = np.array([g.used_budget for g in group])
        restarts    = np.array([g.n_restarts for g in group])

        init_lambdas = np.array(
            [g.lambda_history[0] for g in group if g.lambda_history]
        )
        final_lambdas = np.array(
            [g.lambda_history[-1] for g in group if g.lambda_history]
        )

        aggregated.append(MeanResult(
            func_name=func_name,
            fid=group[0].fid,
            iid=iid,
            func_class="BBOB",
            controller=ctrl_label,
            dim=group[0].dim,
            n_runs=len(group),
            mean_fopt=float(np.mean(fopts)),
            std_fopt=float(np.std(fopts)),
            median_fopt=float(np.median(fopts)),
            best_fopt=float(np.min(fopts)),
            worst_fopt=float(np.max(fopts)),
            mean_used_budget=float(np.mean(budgets)),
            std_used_budget=float(np.std(budgets)),
            mean_n_restarts=float(np.mean(restarts)),
            mean_initial_lambda=float(np.mean(init_lambdas)) if len(init_lambdas) else 0.0,
            mean_final_lambda=float(np.mean(final_lambdas)) if len(final_lambdas) else 0.0,
        ))
    return aggregated

def save_results(
    all_results: List[Result],
    aggregated: List[MeanResult],
    out_dir: str = "results",
) -> None:
    """
    Save raw and aggregated results to CSV files.

    Parameters
    ----------
    all_results : list of RunResult
    aggregated : list of AggregatedResult
    out_dir : str
    """
    os.makedirs(out_dir, exist_ok=True)

    # raw results
    raw_path = os.path.join(out_dir, "raw_results.csv")
    raw_rows = []
    for r in all_results:
        row = {
            "func_name": r.func_name,
            "fid": r.fid,
            "iid": r.iid,
            "run_index": r.run_index,
            "controller": r.controller_name,
            "controller_class": r.controller_name.split("(")[0],
            "dim": r.dim,
            "fopt": r.fopt,
            "used_budget": r.used_budget,
            "n_restarts": r.n_restarts,
            "lambda_history": str(r.lambda_history),
        }
        raw_rows.append(row)

    pd.DataFrame(raw_rows).to_csv(raw_path, index=False)

    # aggregated results
    agg_path = os.path.join(out_dir, "aggregated_results.csv")
    agg_rows = [asdict(a) for a in aggregated]
    pd.DataFrame(agg_rows).to_csv(agg_path, index=False)

    print(f"\nResults saved to '{out_dir}/'")
    print(f"  Raw        : {raw_path}  ({len(raw_rows)} rows)")
    print(f"  Aggregated : {agg_path}  ({len(agg_rows)} rows)")




def print_summary(aggregated: List[MeanResult]) -> None:
    """Print a formatted comparison table to stdout."""
    w = 100
    print(f"\n{'=' * w}")
    print(f"{'BENCHMARK SUMMARY':^{w}}")
    print(f"{'=' * w}")
    print(
        f"{'Function':<22} {'iid':>3} {'Controller':>10} "
        f"{'mean_fopt':>12} {'std_fopt':>12} "
        f"{'success%':>9} {'restarts':>9} {'λ_final':>9}"
    )
    print(f"{'-' * w}")

    prev_func = None
    for r in aggregated:
        if r.func_name != prev_func and prev_func is not None:
            print()
        prev_func = r.func_name
        print(
            f"{r.func_name:<22} {r.iid:>3} {r.controller:>10} "
            f"{r.mean_fopt:>12.3e} {r.std_fopt:>12.3e} "
            f"{r.mean_final_lambda:>9.1f}"
        )

    print(f"{'=' * w}")

    # Per-controller overall averages
    print(f"\n{'OVERALL AVERAGES':^{w}}")
    print(
        f"{'Controller':<12} {'mean_fopt':>14} {'success%':>10} "
        f"{'mean_restarts':>15} {'mean_λ_final':>14}"
    )
    print(f"{'-' * 65}")

    controllers = sorted({r.controller for r in aggregated})
    for ctrl in controllers:
        rows = [r for r in aggregated if r.controller == ctrl]
        print(
            f"{ctrl:<12} {np.mean([r.mean_fopt for r in rows]):>14.3e} "
            # f"{np.mean([r.success_rate for r in rows]) * 100:>9.1f}% "
            f"{np.mean([r.mean_n_restarts for r in rows]):>15.1f} "
            f"{np.mean([r.mean_final_lambda for r in rows]):>14.1f}"
        )
    print(f"{'=' * w}\n")





def main() -> None:
    """Run the benchmark pipeline end-to-end."""
    all_results, aggregated = run_benchmark_coco()

    print_summary(aggregated)
    save_results(all_results, aggregated, out_dir="results")


if __name__ == "__main__":
    main()