"""
Runs a single CMA-ES optimisation episode using modcma, detecting restart
conditions and delegating population-size decisions to a pluggable
PopulationController.
"""

from controllers import PopulationController, CurrentState
from dataclasses import dataclass, field
from modcma import ModularCMAES, Parameters
from typing import Any, Dict, List, Optional, Tuple

# Framework to store individual run results
@dataclass
class Result:
    """
    Complete record of one CMA-Es run.

    Attributes
    -
    f : Callable function
        Target function
    controller_name : str
        Name of the PopulationController used (e.g. 'IPOPController').
    run_index : int
        Which independent repeat this is (0-indexed).
    fopt : float
        Best f(x) - f* achieved.
    used_budget : int
        Function evaluations actually consumed.
    n_restarts : int
        Number of restarts that occurred.
    lambda_history : List[int]
        Population size used in each phase (length = n_restarts + 1).
    fopt_history : List[float]
        Optimal phase at the end of each phase.
    restart_criteria_history : List[Dict[str, bool]]
        Which termination criteria fired at each restart event.
    converged : bool
        True if fopt < convergence_target (default 1e-8, COCO convention).
    """
    f: Any
    controller_name: str
    run_index: int
    fopt: float
    used_budget: int
    n_restarts: int
    lambda_history: List[int] = field(default_factory=list)
    fopt_history: List[float] = field(default_factory=list)
    restart_criteria_history: List[Dict[str, bool]] = field(default_factory=list)




class CMAES:
    """
    Executes one complete CMA-ES optimisation run, possibly including multiple restarts.

    Parameters
    -
    controller : PopulationController
        Any controller implementing select_lambda(CurrentState) -> int.
    """

    def __init__(
        self,
        controller: PopulationController
    ):
        self.controller = controller

    def run(
        self,
        fitness_func: Any,
        run_index: int = 0,
    ) -> Result:
        """
        Optimise fitness_func and return a full run Result.

        Parameters
        -
        fitness_func : Callable function
            The objective to minimise (must return a scalar float, or be a modcma-compatible IOHFunction).
        run_index : int
            Index of this independent repeat.

        Returns
        -
        Result object
        """
        self.controller.reset()

        # Cumulative tracking across restarts
        total_budget_used: int = 0
        n_restarts: int = 0
        best_fopt: float = float("inf")
        lambda_history: List[int] = []
        fopt_history: List[int] = []
        criteria_history: List[Dict[str, bool]] = []

        # FIX: config
        # Initial CMA-ES phase
        cmaes = self.make_runner(fitness_func, getattr(self.controller, 'config', {}), lambda_new=None)
        lambda_history.append(cmaes.parameters.lambda_)

        while True:
            # one generation step
            should_continue = cmaes.step()
            phase_fopt = float(cmaes.parameters.fopt)
            best_fopt = min(best_fopt, phase_fopt)
            fopt_history.append(best_fopt)

            # Notify controller every generation (DRL online-update hook)
            step_state = self._build_state(
                cmaes, n_restarts, total_budget_used, best_fopt
            )
            self.controller.observe_step(step_state)

            # global budget check
            phase_used = int(cmaes.parameters.used_budget)
            cumulative = total_budget_used + phase_used
            if cumulative >= cmaes.parameters.budget:
                total_used = cumulative
                break

            # convergence check
            if best_fopt <= self.convergence_target:
                total_used = cumulative
                break

            # termination criteria / restart
            if not should_continue and self.enable_restarts:
                # Record which criteria fired
                fired = {
                    k: bool(v)
                    for k, v in cmaes.parameters.termination_criteria.items()
                    if v
                }
                criteria_history.append(fired)
                total_used += phase_used

                # Ask controller for new population size
                restart_state = self._build_state(
                    cmaes, n_restarts, total_used, best_fopt,
                    triggered_criteria=fired,
                )
                new_lambda = self.controller.select_lambda(restart_state)
                n_restarts += 1

                # Re-initialise for next phase
                cmaes, _ = self.make_runner(
                    fitness_func, getattr(self.controller, 'config', {}),
                    lambda_new=new_lambda,
                    used_so_far=total_used,
                )
                lambda_history.append(new_lambda)

            elif not should_continue:
                # No restarts enabled; just stop
                total_used += phase_used
                break


        return Result(
            f=fitness_func,
            controller_name=repr(self.controller),
            run_index=run_index,
            fopt=best_fopt,
            used_budget=min(total_used, self.budget),
            n_restarts=n_restarts,
            lambda_history=lambda_history,
            fopt_history=fopt_history,
            restart_criteria_history=criteria_history,
        )

    def make_runner(
        self,
        fitness_func: Any,
        config: Optional[Dict[str, Any]],
        lambda_new: Optional[int],
        used_so_far: int = 0,
    ) -> ModularCMAES:
        """
        Construct a fresh ModularCMAES instance for one restart.

        Parameters
        -
        fitness_func : callable
        config : Dict[str, Any]
            modcma configuration of parameters.
        lambda_new : int or None
            Desired population size.  If None, use modcma default.
        used_so_far : int
            Budget already consumed before this phase.

        Returns
        -
        cmaes : ModularCMAES
        actual_lambda : int
            Population size actually used.
        """
        params = Parameters()
        params.update(config)

        if lambda_new is not None:
            params.update_popsize(lambda_new)

        cmaes = ModularCMAES(fitness_func, parameters=params)
        return cmaes

    def _build_state(
        self,
        cmaes: ModularCMAES,
        n_restarts: int,
        used_so_far: int,
        best_fopt: float,
        triggered_criteria: Optional[Dict[str, bool]] = None,
    ) -> CurrentState:
        """Build a CurrentState from current modcma state."""
        phase_used = int(cmaes.parameters.used_budget)
        cumulative = used_so_far + phase_used
        return CurrentState(
            current_lambda=int(cmaes.parameters.lambda_),
            current_sigma=float(cmaes.parameters.sigma),
            used_budget=cumulative,
            remaining_budget=max(0, self.budget - cumulative),
            n_restarts=n_restarts,
            fopt=best_fopt,
            dim=self.dim,
            triggered_criteria=triggered_criteria or {},
        )






